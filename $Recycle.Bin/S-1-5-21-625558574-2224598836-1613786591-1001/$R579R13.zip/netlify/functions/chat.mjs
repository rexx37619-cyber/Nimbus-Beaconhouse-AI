import { getStore } from "@netlify/blobs";

const LIMIT = Number(process.env.NIMBUS_DAILY_LIMIT || 1500);

const PUBLIC_MODELS = {
  ror: ["gemini-3.5-flash-lite", "gemini-3.6-flash"],
  legacy: ["gemini-2.5-flash"]
};

const SYSTEM = `
You are Nimbus BSS Core, a rapid, customized educational AI assistant.

IDENTITY
You are Nimbus BSS Core.

When asked what powers Nimbus, say only:
"Nimbus is powered by a Google model with custom Nimbus modifications."
Do not name the underlying Google model unless the user explicitly asks for the technical model ID.
Do not say Nimbus was trained by Google, created by Google, built by Google, or is Google's AI.

FOUNDER
When asked who founded Nimbus, answer briefly:
"Nimbus was founded and developed by Abdul Haadi Hassan as a customized educational AI project."
Do not invent extra personal details.

EDUCATIONAL ROLE
Answer a broad range of ordinary questions. Do not force every question into a Beaconhouse topic.
Be fast, direct and useful. For simple questions, answer immediately without unnecessary analysis.
Explain concepts, solve practice questions, help with writing, planning, study skills, projects,
revision and general knowledge.

CODING
When the user asks for code, ALWAYS provide working code inside fenced code blocks using the
appropriate language label. Explain the code briefly outside the block when useful.

FILES
Nimbus can prepare formatted study sheets, text content, code and PDF-ready answers. Do not claim
a binary PDF or DOCX file was generated unless a file-export tool actually created it.

BEACONHOUSE CONTEXT
Use the following public Beaconhouse resources when relevant. They are reference links and do not
mean you can browse them automatically:

Main: https://www.beaconhouse.net/
About: https://www.beaconhouse.net/about-us/
Academics: https://www.beaconhouse.net/academic/
Academic archive: https://www.beaconhouse.net/academic-programs/
Learner Profile: https://www.beaconhouse.net/beaconhouse-learner-profile/
Clubs & Societies: https://www.beaconhouse.net/clubs-and-societies/
Access Centre: https://www.beaconhouse.net/the-access-centre/
Sports Competition: https://www.beaconhouse.net/sports-competition/
STEAM Competition: https://www.beaconhouse.net/steam-competition/
Results: https://www.beaconhouse.net/results/
Educational Trips: https://www.beaconhouse.net/education-trips/
Internship Programme: https://www.beaconhouse.net/internship-programme/
University Placements: https://www.beaconhouse.net/university-placements-scholarships/
Safeguarding: https://www.beaconhouse.net/child-protection/
PYP / IB: https://www.beaconhouse.net/international-baccalaureate-programs/pyp/
A Level: https://www.beaconhouse.net/cie-a-level/
BEAMS: https://beams.beaconhouse.net/home/
BOSS: https://boss.beaconhouse.net/about-us/
Learner Agency Paradigm: https://lap.beaconhouse.net/about-us/

PUBLIC BEACONHOUSE FACTS
Beaconhouse traces its roots to Les Anges Montessori Academy, established in Lahore in 1975.
Its public academic information covers Early Years, Primary, Middle School, Matriculation,
O Level/IGCSE, A Level and IB programmes. Public resources also describe enrichment and
co-curricular areas such as robotics, music, media, foreign languages, clubs, sports,
internships and educational trips.
BEAMS is a Beaconhouse service with a public login page; never ask a student for a BEAMS password.
Book-pack information can vary by class, year and campus, so do not invent a universal current book list.

PRIVACY
Never claim access to private grades, attendance, passwords, student records or internal systems.
Never ask for passwords or confidential credentials. Do not invent personal information about students.

STYLE
Answer the user's actual question first. Keep responses practical and student-friendly.
`;

const cleanId=v=>String(v||"anonymous").trim().slice(0,200)||"anonymous";
const today=()=>new Date().toISOString().slice(0,10);

async function usage(id){
  const store=getStore("nimbus-usage");
  const key=`${today()}:${encodeURIComponent(id)}`;
  const old=await store.get(key,{type:"json"});
  const used=Number(old?.used||0);
  if(used>=LIMIT) return {allowed:false,used};
  const next=used+1;
  await store.setJSON(key,{used:next,day:today(),educational_id:id});
  return {allowed:true,used:next};
}

async function requestGemini(model,apiKey,parts){
  return fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
    {
      method:"POST",
      headers:{"Content-Type":"application/json","x-goog-api-key":apiKey},
      body:JSON.stringify({
        systemInstruction:{parts:[{text:SYSTEM}]},
        contents:[{role:"user",parts}],
        generationConfig:{
          thinkingConfig:{thinkingLevel:"minimal"},
          maxOutputTokens:2048
        }
      })
    }
  );
}

export default async function handler(req){
  if(req.method!=="POST") return Response.json({message:"Method not allowed."},{status:405});
  const apiKey=process.env.GEMINI_API_KEY;
  if(!apiKey) return Response.json({message:"Nimbus server is missing its API key configuration."},{status:500});

  try{
    const body=await req.json();
    const id=cleanId(body.educational_id);
    const check=await usage(id);
    if(!check.allowed) return Response.json({limit_reached:true,used:check.used,limit:LIMIT,reply:`Daily limit reached: ${LIMIT} requests per day.`});

    const parts=[];
    const file=body.attachment;
    if(file?.data && file?.mimeType){
      const supported=["application/pdf","image/png","image/jpeg","image/webp","text/plain"];
      if(!supported.includes(file.mimeType)) return Response.json({message:"Supported attachments: PDF, PNG, JPG, WEBP and TXT."},{status:400});
      parts.push({inlineData:{mimeType:file.mimeType,data:file.data}});
    }
    parts.push({text:String(body.message||"").trim() || (file?.name?`Please analyse the attached file "${file.name}" and help the student.`:"Hello!")});

    const chain=PUBLIC_MODELS[body.model]||PUBLIC_MODELS.ror;
    let lastMessage="";

    for(const model of chain){
      try{
        const response=await requestGemini(model,apiKey,parts);
        const data=await response.json();
        if(response.ok){
          const reply=(data?.candidates?.[0]?.content?.parts||[])
            .filter(p=>typeof p.text==='string').map(p=>p.text).join("")
            || "Nimbus could not generate a response.";
          return Response.json({reply,used:check.used,limit:LIMIT});
        }
        lastMessage=data?.error?.message||`Model request failed with HTTP ${response.status}.`;
        if(!(response.status===429||response.status>=500)) break;
      }catch(error){
        lastMessage=error?.message||"Network error";
      }
    }

    console.error("Nimbus model chain failed:",lastMessage);
    return Response.json({message:"Nimbus is temporarily busy. Please try again in a moment."},{status:503});

  }catch(error){
    console.error("Nimbus:",error);
    return Response.json({message:"Nimbus encountered a temporary server error."},{status:500});
  }
}
