# =========================================================
# NIMBUS AGENT INTEGRATION POINT
# =========================================================
# Paste your Nimbus 0.24 Python agent into this file.
#
# Your frontend/backend contract is:
#
# async def run_agent(message, model, file_path=None, file_name=None) -> str:
#
# Then inside it call your existing Nimbus agent and return ONLY the final
# answer text. Do not put API keys in this file if you can use environment vars.
#
# Example adapter:
#
# async def run_agent(message, model, file_path=None, file_name=None):
#     result = await your_nimbus_agent(
#         prompt=message,
#         model=model,
#         attachment_path=file_path,
#     )
#     return str(result)
#
# If Nimbus 0.24 exposes a different function/class, keep all of that code
# and make this adapter call into it.
#
# The daily 1,500 RPD limit is enforced in backend/main.py BEFORE this agent
# function runs. For production, use Redis/database counters for multiple servers.

from typing import Optional

async def run_agent(message: str, model: str, file_path: Optional[str] = None, file_name: Optional[str] = None) -> str:
    if file_name:
        return f'Demo Nimbus received "{file_name}". Paste your Nimbus 0.24 agent above and call it from run_agent().'
    return f'Demo Nimbus received your message using model "{model}". Paste your Nimbus 0.24 agent above and call it from run_agent().'
